#!/bin/bash
CONFIG="/root/udp/config.json"

TODAY=$(date +%s)
jq --arg today "$TODAY" '
    .users |= map(
        select(
            .expiry == null or 
            (strftime("%s"; .expiry | strptime("%Y-%m-%d"))) > ($today | tonumber)
        )
    )
' "$CONFIG" > /tmp/config.tmp && mv /tmp/config.tmp "$CONFIG"