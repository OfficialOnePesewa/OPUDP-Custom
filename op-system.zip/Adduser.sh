#!/bin/bash
CONFIG="/root/udp/config.json"
/etc/OPUDP/op-system/menu_check.sh 2>/dev/null || true

read -p "Enter username: " user
read -p "Enter password: " pass
read -p "Enter expiry days: " days

expiry=$(date -d "+$days days" +"%Y-%m-%d")

jq --arg user "$user" --arg pass "$pass" --arg exp "$expiry" \
'.users += [{"username": $user, "password": $pass, "expiry": $exp}]' \
"$CONFIG" > /tmp/config.tmp && mv /tmp/config.tmp "$CONFIG"

echo -e "\033[1;32m✓ User $user added! Expiry: $expiry\033[0m"
sleep 2