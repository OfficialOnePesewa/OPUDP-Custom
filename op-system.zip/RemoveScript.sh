#!/bin/bash
echo -e "\033[1;31mRemoving OPUDP Custom Manager...\033[0m"
systemctl stop opudp-custom
systemctl disable opudp-custom
rm -rf /root/udp /etc/OPUDP /usr/local/bin/opcustom
echo "OPUDP removed completely."
sleep 2