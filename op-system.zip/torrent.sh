#!/bin/bash
echo -e "\033[1;33mTorrent Blocker\033[0m"
echo "1. Enable"
echo "2. Disable"
read -p "Choose: " choice

if [ "$choice" = "1" ]; then
    iptables -A OUTPUT -p udp --dport 6881:6889 -j DROP
    echo "Torrent blocking enabled."
else
    iptables -D OUTPUT -p udp --dport 6881:6889 -j DROP 2>/dev/null
    echo "Torrent blocking disabled."
fi
sleep 2