#!/bin/bash
CONFIG="/root/udp/config.json"

read -p "Enter username: " user
read -p "Enter new password: " pass

jq --arg user "$user" --arg pass "$pass" \
'(.users[] | select(.username == $user) | .password) = $pass' "$CONFIG" > /tmp/config.tmp && mv /tmp/config.tmp "$CONFIG"

echo -e "\033[1;32mPassword for $user updated!\033[0m"
sleep 2