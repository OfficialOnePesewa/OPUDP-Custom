#!/bin/bash
CONFIG="/root/udp/config.json"

read -p "Enter username to delete: " user

jq --arg user "$user" '.users |= map(select(.username != $user))' "$CONFIG" > /tmp/config.tmp && mv /tmp/config.tmp "$CONFIG"

echo -e "\033[1;31mUser $user deleted.\033[0m"
sleep 2