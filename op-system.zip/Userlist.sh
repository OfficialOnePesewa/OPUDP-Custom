#!/bin/bash
CONFIG="/root/udp/config.json"
/etc/OPUDP/op-system/menu_check.sh 2>/dev/null || true

echo -e "\033[1;33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
echo -e "\033[1;32m                 Active Users\033[0m"
echo -e "\033[1;33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"

jq -r '.users[] | "👤 Username: \(.username)\n   Password: \(.password)\n   Expiry:   \(.expiry)\n"' "$CONFIG" 2>/dev/null || echo "No users found."

echo -e "\033[1;33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
read -p "Press Enter to return..."